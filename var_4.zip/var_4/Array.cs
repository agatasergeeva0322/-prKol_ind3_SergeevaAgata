﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var_4
{
    class Array
    {
        private int[] array;
        Random rnd = new Random();
        public int[] SizeOfArray(int size)
        {
            array = new int[size];
            for (int i = 0; i < size; i++)
            {
                array[i] = rnd.Next(-100,100);
            }
            return array;
        }

        public string Number(int index)
        {
            if (index >= array.Length || index < 0) return $"Нет элемента с такой позицией";
            else return $"Выбранный элемент: {array[index]}";
        }

        public void Actions()
        {
            
        }
    }
}
