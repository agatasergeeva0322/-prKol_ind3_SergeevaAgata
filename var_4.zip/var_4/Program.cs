﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace var_4
{
    class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists("array.txt"))
            {
                Array array = new Array();
                int size = 0;
                Console.Write("");
                do
                {
                    size = int.Parse(Console.ReadLine());
                }
                while (size <= 0 || size > 20);
                int[] mass = array.SizeOfArray(size);
                for (int i = 0; i < mass.Length; i++)
                {
                    Console.Write($"{mass[i]} ");
                }
            }
            else Console.WriteLine("Файл для записи массива не найден!\nПроверьте наличие 'array.txt' и возвращайтесь");
        }
    }
}
