﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace prackt18
{
    public partial class Form1 : Form
    {
        ArrayList complex = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.ColumnCount = 4;
            dataGridView1.Columns[0].HeaderCell.Value = "Имя пользователя";
            dataGridView1.Columns[1].HeaderCell.Value = "Первое число";
            dataGridView1.Columns[2].HeaderCell.Value = "Второе число";
            dataGridView1.Columns[3].HeaderCell.Value = "Результат";
            dataGridView1.Columns[0].Width = 100;

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            pictureBox1.Image = Image.FromFile("cat.jfif");
            string[] complexnumb = File.ReadAllLines("complexnumb.txt");
            if (complexnumb.Length < 2 || complexnumb.Length > 2)
            {
                groupBox1_ComplexNumbers.Visible = true;
            }
            else
            {
                label10.Visible = true;
                label10.Text = $"Z1 = {complexnumb[0]}\nZ2 = {complexnumb[1]}";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Поле не может быть пустым");

            }
            else
            {
                bool correct_vvod = true;
                for (int i = 0; i < textBox1.Text.Length; i++)
                {
                    if (!char.IsLetter(textBox1.Text[i]))
                    {
                        MessageBox.Show("Имя должна содержать только буквы!");
                        correct_vvod = false;
                        break;
                    }
                }
                if (correct_vvod == true)
                {
                    int a = 0, b = 0, c = 0, d = 0;
                    string[] complexnumb = File.ReadAllLines("complexnumb.txt");
                    if (complexnumb.Length < 2 || complexnumb.Length > 2)
                    {
                        
                        a = Convert.ToInt32(numericUpDown1.Text);
                        b = Convert.ToInt32(numericUpDown2.Text);
                        c = Convert.ToInt32(numericUpDown3.Text);
                        d = Convert.ToInt32(numericUpDown4.Text);
                    }
                    else
                    {
                        if (int.TryParse(complexnumb[0], out a)) a = Convert.ToInt32(complexnumb[0]);
                        else if (complexnumb[0].Contains("i"))
                        {
                            if (complexnumb[0].Contains("-") || complexnumb[0].Contains("+"))
                            {
                                ComplexNumbFromFile(complexnumb[0], out a, out b);
                                b = -b;
                            }
                            else ComplexNumbFromFile(complexnumb[0], out a, out b);
                        }
                        if (int.TryParse(complexnumb[1], out c)) c = Convert.ToInt32(complexnumb[1]);
                        else if (complexnumb[1].Contains("i"))
                        {
                            if (complexnumb[1].Contains("-") || complexnumb[1].Contains("+"))
                            {
                                ComplexNumbFromFile(complexnumb[1], out c, out d);
                                d = -d;
                            }
                            else ComplexNumbFromFile(complexnumb[1], out c, out d);
                        }

                    }
                        StreamWriter r = File.AppendText("result.txt");
                        if (comboBox1.SelectedIndex == 0)
                        {
                            label9.Text = Convert.ToString(ComplexNumber.Add(a, b, c, d));
                        }
                        else if (comboBox1.SelectedIndex == 1)
                        {
                            label9.Text = Convert.ToString(ComplexNumber.Subtract(a, b, c, d));
                        }
                        else
                        {
                            label9.Text = Convert.ToString(ComplexNumber.Multiply(a, b, c, d));
                        }
                    if (complexnumb.Length < 2 || complexnumb.Length > 2) 
                    {
                        string[] mas = new string[2];
                        if (b < 0) mas[0] = $"{a}{b}i";
                        else mas[0] = $"{a}+{b}i";
                        if (d < 0) mas[1] = $"{c}{d}i";
                        else mas[1] = $"{c}+{d}i";
                        r.WriteLine($"{textBox1.Text} {mas[0]} {mas[1]} {label9.Text}");
                    }
                    else r.WriteLine($"{textBox1.Text} {complexnumb[0]} {complexnumb[1]} {label9.Text}");
                    r.Close();
                    string[] str = File.ReadAllLines("result.txt");
                    foreach (string fole in str)
                    {
                        complex.Add(fole);
                    }
                    dataGridView1.RowCount = complex.Count;
                    for (int i = 0; i < complex.Count; i++)
                    {
                        string tex = (string)complex[i];
                        string[] sl = tex.Split(' ');
                        dataGridView1[0, i].Value = sl[0];
                        dataGridView1[1, i].Value = sl[1];
                        dataGridView1[2, i].Value = sl[2];
                        dataGridView1[3, i].Value = sl[3];
                    }
                }
            }
        }
        public void ComplexNumbFromFile(string stroka, out int a, out int b)
        {
            a = 0;
            b = 0;
            int ind = stroka.IndexOf("-");
            if (ind == -1) ind = stroka.IndexOf("+");
            if (ind == -1)
            {
                a = 0;
                string cn = "";
                for (int i = 0; i < stroka.Length-1; i++)
                {
                    cn += stroka[i];
                }
                b = Convert.ToInt32(cn);
            }
            else if (ind == 0)
            {
                a = 0;
                string cn = "";
                for (int i = 1; i < stroka.Length-1; i++)
                {
                    cn += stroka[i];
                }
                b = Convert.ToInt32(cn);
            }
            else
            {
                string cn = "";
                for (int i = 0; i < ind; i++)
                {
                    cn += stroka[i];
                }
                a = Convert.ToInt32(cn);
                cn = "";
                for (int i = ind + 1; i < stroka.Length-1; i++)
                {
                    cn += stroka[i];
                }
                b = Convert.ToInt32(cn);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var data = dataGridView1.Rows.Cast<DataGridViewRow>().Select(row => new
            {
                Col1 = row.Cells[0].Value,
                Col2 = row.Cells[1].Value,
                Col3 = row.Cells[2].Value,
                Col4 = row.Cells[3].Value
            }).ToList();
            var sorted = data.OrderBy(d => d.Col1);
            for (int i = 0; i < sorted.Count(); i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = sorted.ElementAt(i).Col1;
                dataGridView1.Rows[i].Cells[1].Value = sorted.ElementAt(i).Col2;
                dataGridView1.Rows[i].Cells[2].Value = sorted.ElementAt(i).Col3;
                dataGridView1.Rows[i].Cells[3].Value = sorted.ElementAt(i).Col4;
            }
        }
    }
}

